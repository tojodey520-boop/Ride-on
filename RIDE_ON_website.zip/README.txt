RIDE ON website
Open index.html in a browser.
Booking form sends the booking request to WhatsApp number 6294712674.
To publish online, upload index.html and car.jpeg to a static hosting service.
